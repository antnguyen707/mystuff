#!/bin/bash

if [ "$#" -ne 1 ]; then
	echo "Usage: ./apply_patch.sh [android-x68 tree directory path]"
	exit
fi 

cp ./CMFileManager.patch $1/packages/apps/CMFileManager
cp ./frameworks_base.patch $1/frameworks/base
cp ./frameworks_native.patch $1/frameworks/native
cp ./settings.patch $1/packages/apps/Settings
cp ./Trebuchet.patch $1/packages/apps/Trebuchet


cd $1/packages/apps/CMFileManager/
git apply -p1 -v CMFileManager.patch
cd $1/frameworks/base/
git apply -p1 -v frameworks_base.patch
cd $1/frameworks/native/
git apply -p1 -v frameworks_native.patch
cd $1/packages/apps/Settings/
git apply -p1 -v settings.patch
cd $1/packages/apps/Trebuchet/
git apply -p1 -v Trebuchet.patch


rm $1/packages/apps/CMFileManager/CMFileManager.patch
rm $1/frameworks/base/frameworks_base.patch
rm $1/frameworks/native/frameworks_native.patch
rm $1/packages/apps/Settings/settings.patch
rm $1/packages/apps/Trebuchet/Trebuchet.patch 